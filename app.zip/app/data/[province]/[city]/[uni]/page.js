"use client";
import { useParams } from "next/navigation"

// slug
// product ki SEO behtr krne keliye aur product ko
// uniquely identify krne keliye slug use hota
// 1-9pro-5g-beast-phone-iid-1091568814

export default()=>{

    // useParams() is a hook
    // hook means koi specific functionality
    // react aur uski plugins m different kaam krne keliye 
    // dozens of hooks available hn


    // /product-detail/1000

    let data = useParams();

    return <div>
        <h1>{data.province}</h1>
        <h1>{data.city}</h1>
        <h1>{data.uni}</h1>
        yeh data h 
    </div>

}