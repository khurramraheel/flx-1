export let ads = [
    {
      name: 'VIVO A1',
      price: 2000,
      description:""
    },
    {
      name: 'HP A10',
      price: 1600,
      description:""
    },
    {
      name: 'DELL 560',
      price: 1800,
      description:""
    }
  ]