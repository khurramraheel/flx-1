export default()=>{

    return <h1>
        Yeh page se aya
    </h1>

}