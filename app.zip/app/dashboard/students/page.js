export default()=>{

    return <div>
        yeh stude page agya
    </div>
}