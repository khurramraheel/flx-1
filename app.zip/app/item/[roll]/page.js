"use client";
import { useParams } from "next/navigation"


    // /data/punjab//fsd /gc
// /data/province/city/uni

export default function (){

    // useParams() hamesha {} return karta h
    let params = useParams();

    return <div>
        yeh prduct wala page {params.roll}
    </div>

}