let NotFound = ()=>{

    return <div className="page-not-found">
        <h1>page nahi milya!</h1>
    </div>

}

export default NotFound;