export default function GC(){

    return <div>
        <h1>yeh internal GC wala path</h1>
    </div>

}