"use client";
import { useDispatch, useSelector } from 'react-redux';
import './login.css';
import { useForm } from 'react-hook-form';
import { toast } from 'react-toastify';
import { useRouter } from 'next/navigation';
import ReduxProvider from '@/components/reduxProvider/reduxProvider';
import { loginHogya } from '@/store/userSlice';

// let data = {
    // city:'fsd'
// }

// let {city} =  data;

export default function Page(){

  return <ReduxProvider>
        <LoginWala></LoginWala>
  </ReduxProvider>

}

function LoginWala(){

  let router = useRouter();
  let dispatch = useDispatch();

  let users = useSelector(function(store){
    return store.userSlice.users
  })


    let {register, handleSubmit} = useForm();

    const saveKaro = (meraData)=>{

      let userMilgya = users.find(function(user){

        if(user.name == meraData.userEmail && user.password == meraData.userPassword){
          return true;
        }

      });

      if(userMilgya){

        dispatch( loginHogya(userMilgya) )

        router.push('/dashboard');

      }else{
        toast.error("user koi nahi")
      }
        

    }

    return <div className="wrapper fadeInDown">
    <div id="formContent">
      {/* Tabs Titles */}
      {/* Icon */}
      <div className="fadeIn first">
        <img
        width={50}
          src="1.png"
          id="icon"
          alt="User Icon"
        />
      </div>
      {/* Login Form */}
      <form onSubmit={ handleSubmit(saveKaro) }>
        <input
            {...register('userEmail')}
          type="text"
          id="userEmail"
          className="fadeIn second"          
          placeholder="login"
        />
        <input
          type="text"
          {...register('userPassword')}
   
          className="fadeIn third"
        
          placeholder="password"
        />

        <select {...register('userCity')}>
            
            {/* value = "" means yeh option valid nahi hoga */}
            <option value="">Select City</option>

            <option>FSD</option>
            <option>Gojra</option>
            <option>Toba</option>
            <option>Jhumra</option>
        </select>
       
        <input type="submit" className="fadeIn fourth" defaultValue="Log In" />
      </form>
      {/* Remind Passowrd */}
      <div id="formFooter">
        <a className="underlineHover" href="#">
          Forgot Password?
        </a>
      </div>
    </div>
  </div>
  

}