"use client";
import { setUser } from '@/store/auth';
import axios from 'axios';
import { useEffect } from "react";
import { useDispatch } from 'react-redux';

export default()=>{

    let dispatch = useDispatch();

    useEffect(()=>{

        axios.post('/api/signup', {
            token:localStorage.getItem('token'),
            action:"session-check"
        }).then((resp)=>{

            if(resp.data.user){
                // jo user mila h usko store m send karden takay session resume hojye
                dispatch(setUser(resp.data.user));
            }

        })

    }, [])

    return <>
    </>

}