"use client";
import './cart.css';
import { useDispatch, useSelector } from "react-redux"
import { NumericFormat } from 'react-number-format';
import { decItem, incItem, removeItem } from '@/store/cart';

export default()=>{

    let dispatch = useDispatch();

    let items =  useSelector(store=>{
        return store.cartSlice.items;
    });

    return <div>

        {
           !items.length ?
            <div className="text-center">Your Shopping Cart is empty</div> :
            <table className="no-input">
                <thead>
                    <th></th>
                    <td>Name</td>
                    <td>Price</td>
                    <td>Qty</td>
                    <td>Sub Total</td>
                </thead>
            {
                items.map(function(item){
                    return <tr>
                        <td>
                            <img width={100} src={item.pic || "/not-available.png"} />
                            </td>
                        <td>
                            {item.name}
                            </td>
                        <td>
                        <NumericFormat value={item.price} allowLeadingZeros thousandSeparator="," />
                        </td>
                        <td>
                            {item.qty}
                            
                            <button onClick={e=> dispatch(incItem(item))}>+</button>
                            
                            <button onClick={function(e){
                                 dispatch(decItem(item))
                            }}>-</button>
                            
                        </td>
                        <td>
                            {item.price * item.qty}
                        </td>
                        <td>
                            <button onClick={()=>{

                                dispatch(removeItem(item._id));

                            }}>X</button>
                        </td>
                    </tr>
                })
            }
            <tr>
                <th>
                    Total Bill
                </th>
                <th className="no-input">                    
                    {
                        <NumericFormat value={
                            items.reduce((a, b)=>{
                                return {qty:1, price:(a.price * a.qty) + (b.price * b.qty)}
                               }, {price:0, qty:0}).price
                        } allowLeadingZeros thousandSeparator="," />
                       
                    }</th>
            </tr>

        </table>
        }

        

    </div>

}