import { User } from "@/models/user";
import { NextResponse } from "next/server";
import { verify, sign } from 'jsonwebtoken'


function verifyUser(token) {

    return new Promise(function (_then, _catch) {

        verify(token, 'mioon says cat', async function (err, data) {

            if (data) {
                _then(data);
            } else {
                _catch(err)
            }

        })
    });


}

// function GET(req){}

// function POST(req){ }

// function DELETE(req){}

// function PUT(req){}




export async function DELETE(req) {

    console.log(req.nextUrl.searchParams.get("abc"))

    // /api/signup?d=10&city=fsd
    // query param se data uthana
    let id = req.nextUrl.searchParams.get("abc");//10
    // let id = req.nextUrl.searchParams.get("city");//fsd

    // mongoose m ID se record ko delete krna
    await User.findByIdAndDelete(id);

    // request ka answer back krna
    return NextResponse.json({ success: true })

}

export async function PUT(req) {

    // incoming data pakarna
    let data = await req.json();
    console.log(data);

    await User.findByIdAndUpdate(data._id, data);

    // request ka answer back krna
    return NextResponse.json({ success: true })

}


export async function GET(req) {

    let mereUsers = await User.find();

    // request ka answer back krna
    return NextResponse.json({ users: mereUsers })

}

export async function POST(req) {

    // incoming data pakarna
    let data = await req.json();
    console.log(data);

    if (data.action == "signup") {

        let nyaUser = new User(data)
        await nyaUser.save();

    } else if (data.action == "login") {

        let user = await User.findOne({
            user_email:data.user_email, 
            user_password:data.user_password 
        });


        if (user) {

            // sign() aapko token generate karke deta
            let token = sign({ meriID: user._id }, 'mioon says cat', { expiresIn: '1h' });


            console.log(token)

            return NextResponse.json({
                user,
                token
            })

        }

        return NextResponse.json(null)




    } else if (data.action == "session-check") {

        try {

            let verifiedData = await verifyUser(data.token);

            if (verifiedData) {

                console.log("***************")
                console.log(verifiedData)

                let user = await User.findById(verifiedData.meriID);

                console.log("############################")
                console.log(user)

                return NextResponse.json({
                    user
                });


            }

        } catch (e) {

            console.log("000000000000000000000")
            console.log(e)

            return NextResponse.json({});

        }






    }

    console.log('code chal gya wa')

    // request ka answer back krna
    return NextResponse.json({
        success: true
    });

}